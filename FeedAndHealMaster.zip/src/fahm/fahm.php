<?php

namespace fahm;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\utils\Config;

class fahm extends PluginBase implements Listener{
  public function onEnable(){
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    @mkdir($this->getDataFolder());
    $this->saveResource("config.yml");
    $this->saveDefaultConfig();
    $this->getLogger()->info("FeedAndHealMaster enabled! Author: KakKanalPeretz");
  }
  public function onCommand(CommandSender $s, Command $cmd, string $label, array $args) : bool{
    if($cmd->getName() == "feed"){
      $s->setFood($this->getConfig()->get("feed.count"));
      $s->sendMessage($this->getConfig()->get("feed.msg"));
      return true;
    }
    if($cmd->getName() == "heal"){
      $s->setHealth($this->getConfig()->get("heal.count"));
      $s->sendMessage($this->getConfig()->get("heal.msg"));
      return true;
    }
  }
}
?>